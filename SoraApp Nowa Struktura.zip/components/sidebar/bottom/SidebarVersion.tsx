export default function SidebarVersion() {
  return (
    <span className="mt-[4px] pl-[12px] pr-[12px] pb-[10px] text-[10px] text-slate-500 dark:text-slate-400">
      v0.0.1.4
    </span>
  )
}
