// components/MiniSidebar/bottom/SidebarVersion.tsx
// Komponent SidebarVersion (mini) – etykieta wersji aplikacji na dole mini sidebaru

export default function SidebarVersion() {
  return (
    <span className="mt-[4px] text-center text-[10px] text-slate-500 dark:text-slate-400">
      v0.0.1.4
    </span>
  )
}
