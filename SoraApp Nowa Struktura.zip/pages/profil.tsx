export default function Profil() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Profil użytkownika</h1>
      <p className="text-slate-600 dark:text-slate-300 mt-2">Tu będą dane konta i opcje edycji.</p>
    </div>
  )
}
